=== Wonderflow ===
Contributors: Wonderflow BV
Tags: reviews,videos,ecommerce,plugin,automatic,products,reviews provider,review,video,youtube,content,specifications
Author URI: https://profiles.wordpress.org/wonderflow/
Plugin URI: http://wonderflow.co
License: GPLv2
Requires at least: 2.0.2 or higher
Tested up to: 3.9
Stable tag: 0.0.1

Instantly add text and video reviews to your product pages. Use our reviews and sell more, today.

== Description ==

= Description =

Reviews and videos about products boost ecommerce conversions and time on site.

They are an obvious choice if you want to increase sales.

The **problem** is that searching, gathering and publishing all this information on each product page is time consuming and expensive.

So Wonderflow does this for you, by searching the web for the best reviews and videos about products you sell.

We provide you with a widget for the product pages on your site and a seamless user experience.

**Your sales pages will be enriched with high quality reviews and videos**.

Our research demonstrates that this can help you sell up to 30% more.

Our reviews and videos are strictly relevant to what you sell. An high match ratio ensures valuable information for all your products. A use of independent text and video reviews will increase trust on your site.

So get started today. Use Wonderflow. Fill your site with great product information.

Increase sales!

= Features =

* Our widget displays reviews and videos in any language you want. 
* Videos and text reviews we display are carefully selected. We ensure that our content is relevant for you products.
* Dead easy to instal, just copy/paste a script.
* Our widget can stand on top of any web page (right or left) or can be embedded wherever you like inside your design [Contact us](mailto:hello@wonderflow.co) to request a trial of all different versions.


== Installation ==

Just 5 minutes:
1. download and install this Wordpress plugin
2. make sure you display product ID numbers on your sales pages (If you can’t do this, please contact us)

and that's it!

Just wait some minutes and It will work!

[Drop us a line](mailto:hello@wonderflow.co) if you face any problem.


== Screenshots ==

1. screenshot-1.jpg
2. screenshot-2.jpg


== Frequently Asked Questions ==

If you have any question, please drop us a line to [hello@wonderflow.co](mailto:hello@wonderflow.co). 

A member of Wonderflow team will answer to you within 24h, and your question might be included in this README.

== Note about Wonderflow plugin ==


* It supports localization to provide shoppers with good information.
* It is fully loaded by Wonderflow's servers.
* We injects a safe Javascript and a Css file inside your product pages. 
* For more information contact us at [hello@wonderflow.co](mailto:hello@wonderflow.co)


== Changelog ==




