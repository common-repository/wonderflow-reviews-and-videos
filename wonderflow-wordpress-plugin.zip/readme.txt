=== Wonderflow ===
Contributors: Wonderflow.co
Tags: reviews,videos,ecommerce,plugin,automatic
License: GPLv2 or later
Requires at least: 3.9
Tested up to: 3.9
Stable tag: 3.9

The best service for ecommerce stores to add videos and reviews automatically to their product pages.

== Description ==

Reviews and videos about product boost ecommerce conversions and time on site.

They are an obvious choice if you want to increase sales.

The **problem** is that searching, gathering and publishing all this information on each product page is time consuming and expesive.

So Wonderflow does this for you, by searching the web for the best reviews and videos about products you sell.

We provide you with a widget for the product pages on your site and the seamless user experience.

**Your sales page will be enriched with high quality reviews and videos**.

Our research demonstrates that this can help you sell up to 30% more.

Our reviews and videos are strictly relevant to what you sell. An high match ration ensures valuable information for all your products. A use of independent text and video reviews will increase trust on your site.

So get started today. Use Wonderflow. Fill your site with great product information.

Increase sales!

== Installation ==

To install Wonderflow service you just have to do only 2 things:
1. download and install this Wordpress plugin
2. publish on your product pages the product code related to the product sold on that page

and that's it!

Our plugin will start to work some minutes after the installation (because we need to setup a function on our own server to get the product code from your page).


== Frequently Asked Questions ==

If you have any question, please drop a line to [hello@wonderflow.co](mailto:hello@wonderflow.co). 

A member of Wonderflow team will answer you before 24h, and your question will be included in this README.


== Note about Wonderflow plugin ==

* It invokes Http requests to only Wonderflow's servers
* It does not invoke any malicious code 
* It injects a Javascript and a Css file inside the product page to enable the page to display content about the product the page is about
* for more information contact us at [hello@wonderflow.co](mailto:hello@wonderflow.co)




