<?php

/*
 Plugin Name: Wonderflow
 Plugin URI: http://wonderflow.co
 Description: This plugin publishes automatically high quality reviews and videos on product pages, to sell more.
 Version: 1.0.0-RC1
 Author: Wonderflow.co
 Author URI: http://wonderflow.co/
 */

add_action( 'wp_head', 'wonderflow_add_script' );
add_action('admin_menu', 'wonderflow_plugin_settings');

function wonderflow_plugin_settings() {

    add_menu_page('Wonderflow', 'Wonderflow Settings', 'administrator', 'wonderflow_settings', 'wonderflow_display_settings');

}

function wonderflow_display_settings() {

    $api_key=(get_option('wonderflow_api_key') != '') ? get_option('wonderflow_api_key') : '';

    $html = '</pre>
<div class="wrap"><form action="options.php" method="post" name="options">
<h2>Select Your Settings</h2>
' . wp_nonce_field('update-options') . '
<table class="form-table" width="100%" cellpadding="10">
<tbody>

<tr>
<td scope="row" align="left">
 <label>API Key</label><input type="text" name="wonderflow_api_key" value="'.$api_key.'" /></td>
</tr>
</tbody>
</table>
 <input type="hidden" name="action" value="update" />

 <input type="hidden" name="page_options" value="wonderflow_api_key" />

 <input type="submit" name="Submit" value="Update" /></form></div>
<pre>
';

    echo $html;

}




function wonderflow_add_script() {
	$script = '
			<script id="wonderflow-script">			
			(function(){
			    var myscript = document.createElement("script");
			    var url = "http://wonderflow.co/demo/private/wordpress.1";
			    myscript.type = "text/javascript";
			    myscript.src = "http://wonderflow.co/script/get?url=" + url;
			    myscript.async = true;
			    var s = document.getElementById("wonderflow-script");
			    s.parentNode.insertBefore(myscript, s);				

			})();
			</script>			
	';
 
	echo $script;

	//echo '<link rel="stylesheet" type="text/css" href="https://s3-eu-west-1.amazonaws.com/europe.flowsby.com/widget-plugin/widget-plugin-style.min.css"></link>';
//	echo '<link rel="stylesheet" type="text/css" href="'.get_template_directory_uri().'/widget-plugin-style.min.css"></link>';
	echo '<link rel="stylesheet" type="text/css" href="'.plugins_url('widget-plugin-style.min.css',__FILE__).'"></link>';
//plugins_url( 'images/wordpress.png' , __FILE__ )
}
